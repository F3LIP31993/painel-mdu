import React from 'react'
import ReactDOM from 'react-dom/client'

const App = () => <h1>Painel MDU</h1>

ReactDOM.createRoot(document.getElementById('root')).render(<App />)